# Morning Greetings

This package automates the process of sending personalized "Good Morning" messages to a list of friends.

## Installation

To install the package locally, run:
