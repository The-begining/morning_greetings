def generate_message(name):
    return f"Good Morning, {name}! Have a great day!"