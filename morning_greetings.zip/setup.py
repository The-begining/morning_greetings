from setuptools import setup, find_packages

setup(
    name="morning_greetings",
    version="0.1",
    packages=find_packages(),
    description="A package for sending automated Good Morning messages",
    author="Your Name",
    author_email="your.email@example.com",
    install_requires=[],
)
